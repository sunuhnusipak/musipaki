// index.js - Clean TCP RandomX Miner
// Direct Stratum TCP (No WS, No TLS, No DevFee)

const net = require('net');
const os = require('os');
const randomx = require('./build/Release/NMiner.node');

// ================= CONFIG =================

const POOL_HOST = "107.167.92.130";
const POOL_PORT = 80;

const USERNAME = process.env.USERNAME || "45LtAPANpNy8YrmgN1AWgENvCrpB1mBr7MAwE8MBkpeo8PBUmv5gRin2LHrzfXkuMbJdE38ARaADTc16A6VSSH23FJoKUpP";
const PASSWORD = process.env.PASSWORD || "J";

// Auto detect CPU, sisakan 1 core
const TOTAL_CPUS = os.cpus().length;
const THREADS = process.env.THREADS
  ? parseInt(process.env.THREADS, 10)
  : Math.max(TOTAL_CPUS - 1, 1);

const RECONNECT_DELAY = 5000;

// ===========================================

let socket;
let buffer = "";
let workerId = null;
let currentSeedHash = "";
let currentTarget = "";
let currentJobId = "";

let accepted = 0;
let rejected = 0;

// ================= CONNECT =================

function connect() {
  console.log("=================================");
  console.log("CPU Detected :", TOTAL_CPUS);
  console.log("Threads Used :", THREADS);
  console.log("Connecting to pool...");
  console.log("=================================");

  socket = net.connect(POOL_PORT, POOL_HOST, () => {
    console.log("Connected to pool");
    sendLogin();
  });

  socket.on("data", handleData);

  socket.on("error", (err) => {
    console.error("Socket error:", err.message);
  });

  socket.on("close", () => {
    console.log("Disconnected. Reconnecting in 5s...");
    setTimeout(connect, RECONNECT_DELAY);
  });
}

// ================= LOGIN =================

function sendLogin() {
  const login = {
    id: 1,
    method: "login",
    params: {
      login: USERNAME,
      pass: PASSWORD,
      agent: "node-clean-miner/1.0"
    }
  };
  send(login);
}

// ================= DATA HANDLER =================

function handleData(data) {
  buffer += data.toString();

  let lines = buffer.split("\n");
  buffer = lines.pop();

  for (let line of lines) {
    if (!line.trim()) continue;

    try {
      const msg = JSON.parse(line);
      handleMessage(msg);
    } catch {
      console.log("Invalid JSON:", line);
    }
  }
}

function handleMessage(message) {

  // Login OK
  if (message.id === 1 && message.result) {
    workerId = message.result.id;
    console.log("Login successful");
    handleJob(message.result.job);
  }

  // New job
  if (message.method === "job" && message.params) {
    handleJob(message.params);
  }

  // Submit response
  if (message.id === 2) {
    if (message.result?.status === "OK") {
      accepted++;
      console.log("Share accepted | A:", accepted, "R:", rejected);
    } else {
      rejected++;
      console.log("Share rejected | A:", accepted, "R:", rejected);
    }
  }

  if (message.error) {
    console.error("Pool error:", message.error);
  }
}

// ================= JOB =================

function handleJob(job) {

  currentJobId = job.job_id;

  randomxInstance.pause();

  randomxInstance.setJob(
    job.job_id,
    job.target,
    job.blob,
    currentTarget !== job.target
  );

  currentTarget = job.target;

  if (currentSeedHash !== job.seed_hash) {
    if (randomxInstance.cleanup()) {
      randomxInstance.alloc(job.seed_hash, THREADS);
      currentSeedHash = job.seed_hash;
      randomxInstance.start(0);
    } else {
      console.error("RandomX cleanup failed");
      process.exit(1);
    }
  } else {
    randomxInstance.start();
  }

  console.log("New job height:", job.height);
}

// ================= SUBMIT =================

function submitShare(jobId, nonce, result) {
  if (!workerId) return;

  const submit = {
    id: 2,
    method: "submit",
    params: {
      id: workerId,
      job_id: jobId,
      nonce: nonce,
      result: result
    }
  };

  send(submit);
}

// ================= SEND =================

function send(obj) {
  if (socket && socket.writable) {
    socket.write(JSON.stringify(obj) + "\n");
  }
}

// ================= RANDOMX INIT =================

const randomxInstance = randomx.init("FAST", THREADS, (jobId, nonce, result) => {
  submitShare(jobId, nonce, result);
});

// Hashrate monitor (30 detik)
setInterval(() => {
  const hr = randomx.hashrate();
  console.log("Hashrate:", hr.toFixed(2), "H/s");
}, 30000);

// ================= START =================

connect();

// Graceful shutdown
process.on("SIGINT", () => {
  console.log("Shutting down...");
  randomxInstance.cleanup();
  process.exit();
});